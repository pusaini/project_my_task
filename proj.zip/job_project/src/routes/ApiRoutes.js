export const ApiRoute = {
    
    getAllAds: "getAllAds",
    ads: "ads",
 

}