import { ApiRoute } from "../routes/ApiRoutes";
import { API_URL } from "./Url";

export const getAllAds = async () => {
    const response = await fetch(`${API_URL.BASIC_URL}${ApiRoute.getAllAds}`);
    return await response.json();
}

export const search = async (word) => {
    const response = await fetch(`${API_URL.BASIC_URL}${ApiRoute.ads}?keyword=${word}`);
    return await response.json();
}