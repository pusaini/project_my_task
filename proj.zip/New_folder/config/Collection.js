module.exports = {
    Advertisement_Company:"adcompany",
    Advertisement_Description:"addescription"
}