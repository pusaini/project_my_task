export const API_URL = {
    BASIC_URL:"http://localhost:3001/advertise/",  
    IMAGE_URL:"http://localhost:3000/image/" 
}