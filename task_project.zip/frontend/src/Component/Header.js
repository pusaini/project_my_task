import React from "react";
// import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import "../Component/Header.css"
export function Header(props) {
 
    function getOnChange(event) {
      props.keyword(event.target.value)
    }
  
    return (
        <>
            <Container fluid>
                <Row  >
                    <Col className="background" ></Col>
                    <Col  className="background"> <Form className="d-flex" >
                        <Form.Control
                            type="search"
                            placeholder="Enter Prodect Name"
                            onChange={(event) => { getOnChange(event) }}
                            className="me-2"
                            name="value"
                            aria-label="Search"
                        />
                        {/* <Button variant="outline-warning" type='submit'>Search</Button> */}
                    </Form></Col>
                    <Col  className="background"></Col>
                </Row>
            </Container>

        </>
    )
}