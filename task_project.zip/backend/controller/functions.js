const schema = require("../model/schemas");
module.exports = {
    async getadvertisement(key){
        let response = {};
        try{
            console.log("hello")
            const result = await schema.advertise.aggregate([
                {
                    $match:{
                        $or:[
                            {"primary_text":{$regex:`${key}`,$options:"i"}},
                            {"headline":{$regex:`${key}`,$options:"i"}},
                            {"description":{$regex:`${key}`,$options:"i"}},
                        ]
                    }
                },
                {
                    $lookup:{
                      from: "adcompanies",
                      localField: "company_id",
                      foreignField: "company_id",
                      as: "company"
                    }
                }
             ]);
            if(result){
                response.status = "success"
                response.message = "data found"
                response.data = result
            }      
        }catch(error){
           response.status = "failed";
           response.message = "data not found";      
        }
        return response;
    },
    async getalladvertisements()
    {
        const response = {}
        try{
            const result = await schema.advertise.find();
            if(result){
                response.status = "success";
                response.data = result
            }
        }
        catch(err){
            response.status = "failed";
        }
        return response;
    }
}