const mongoose = require("mongoose");
require("../config/database");
const collection = require("../config/collection");
const companies = new mongoose.Schema({
        company_id:{type:Number,required:[true,"id is required , Should be of type number"]},
        company_name:{type:String,required:[true,"name is required , Should be of type string"]},
        company_url:{type:String,required:[true,"url is required , Should be of type String"]},
    })
const advertisements = new mongoose.Schema({
    company_id:{type:Number,required:[true,"id is required , Should be of type number"]},
    primary_text:{type:String},
    headline:{type:String},
    description:{type:String},
    cta:{type:String},
    image_url:{type:String}
})    
const company = mongoose.model(collection.company,companies);
const advertise = mongoose.model(collection.advertisement,advertisements);
module.exports = {
    company:company,
    advertise:advertise
}
