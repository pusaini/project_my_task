module.exports = {
    company:"companynames",
    advertisement:"advertisements"
}