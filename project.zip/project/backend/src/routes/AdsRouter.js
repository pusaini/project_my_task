const express = require("express");
const advertise = require("../controller/AdsController");
const querystring = require("querystring");
const url = require("url")
const router = express.Router();
router.get("/ads", async (request,response)=>{
  const x = await querystring.parse(url.parse(request.url).query);
  advertise.getAdvertisement(x.keyword).then((result)=>{
  response.json(result);
    })    
})
router.get("/getAllAds", async (request,response)=>{
  const res =  await advertise.getAllAdvertisements()
  response.json(res)    
})
module.exports = router;