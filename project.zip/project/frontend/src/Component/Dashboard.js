import React, { useEffect, useState } from "react";
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import { getAllAds, search } from "../api/Api";
import { Header } from "./Header";
import { API_URL } from "../api/Url";
import "../Component/Dashboard.css"
export function Dashboard() {
  const [ads, setAds] = useState([])

  useEffect(() => {
    getAllAds().then((response) => {
      console.log(response)
      if (response.status == "success") {
        setAds(response.data)
      }
    })
  }, [])

  async function KeywordSearch(keyword) {
    console.log(keyword)
    if (keyword == "") {
      const res = await getAllAds();
      if (res.status == "success") {
        setAds(res.data)
      }
    }
    else {
      const res = await search(keyword);
      console.log(res);
      setAds(res)
    }
  }

  return (
    <>
      <Header keyword={KeywordSearch} />
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-12">
            <div className="row justify-content-left">

              {
                ads.map((data, i) =>
                  <div className="col-md-3 gy-3 gx-3 d-flex">
                    <Card className="cardd">
                      <Card.Img variant="top" src={`${API_URL.IMAGE_URL}sh.jpg`} />
                      <Card.Body>
                      <Card.Title className="head">{data.primary_text}</Card.Title>
                        <Card.Text className="prmtxt">{data.headline}</Card.Text>                       
                        <Card.Text className="desc">{data.description}</Card.Text>
                        <Button className="ButtonD" variant="primary">{data.cta}</Button>
                      </Card.Body>
                    </Card>
                  </div>
                )}

            </div>
          </div>
        </div>
      </div>
    </>
  )
}